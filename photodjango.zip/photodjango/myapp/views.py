from django.shortcuts import render
from django.http import HttpResponse
from myapp.fun import handle_uploaded
from myapp.forms import *
from myapp.models import *
# Create your views here.

def save(request):
	if request.method=='POST':
		form=ImageForm(request.POST, request.FILES)
		if form.is_valid():
			form.save()
			handle_uploaded(request.FILES['img'])
			return HttpResponse('Image Save')
	else:
		form=ImageForm()
	return render(request, 'index.html', {'form':form})

def show2(request):
	if request.method=='POST':
		img=ImageShow(request.POST)
		if img.is_valid():
			iname=request.POST['name']
			obj = ImageData.objects.get(name=iname)
			imagename=obj.img
			return render(request,'show2.html', {'image':imagename})
	else:
		img=ImageShow()
		return render(request,'show.html', {'name':img})
