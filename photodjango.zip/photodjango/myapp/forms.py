from django import forms
from myapp.models import *

class ImageForm(forms.ModelForm):
	class Meta:
		model=ImageData
		fields='__all__'
class ImageShow(forms.ModelForm):
	class Meta:
		model=ImageData
		fields=['name']
