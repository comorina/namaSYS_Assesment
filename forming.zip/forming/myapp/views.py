from django.contrib import messages
from django.shortcuts import render, redirect
from django.http import HttpResponse
from myapp.forms import *
from django.contrib.auth import authenticate, login
# Create your views here.
ps1=0
def home(request):
    return render(request, 'index.html')
def register(request):
    if request.method=="POST":
        form = RegisterForm(request.POST, request.FILES)
        if form.is_valid():

            try:
                ps1 = request.POST['pass1']
                ps2 = request.POST['pass2']
                if ps1 == ps2:
                    form.save()
                    messages.success(request, "Your Account has been Created")
                    #return HttpResponse('Saved')
                    return redirect("/login")
                else:
                    return HttpResponse("<h4>Mis Match password</h4>")
            except:
                pass
    else:
        form = RegisterForm()
        return render(request, "register.html", {'form':form})

def login(request):
    if request.method=="POST":
        form=SignInForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, "welcome.html")
    else:
        form = SignInForm()
        return render(request, "login.html", {'form':form})
def show(request):
    form = Register.objects.all()
    return render(request, "show.html", {'form':form})