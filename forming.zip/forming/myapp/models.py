from django.db import models

# Create your models here.
class Register(models.Model):
    uname = models.CharField(max_length=30)
    email = models.EmailField(primary_key=True)
    pass1 = models.CharField(max_length=8)
    pass2 = models.CharField(max_length=8)
    address = models.CharField(max_length=100)
class SignIn(models.Model):
    uname = models.CharField(max_length=30)
    pass1 = models.CharField(max_length=8)

