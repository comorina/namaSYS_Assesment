from django import forms
from myapp.models import *

class RegisterForm(forms.ModelForm):
    class Meta:
        model = Register
        fields = '__all__'

class SignInForm(forms.ModelForm):
    class Meta:
        model = SignIn
        fields = "__all__"
